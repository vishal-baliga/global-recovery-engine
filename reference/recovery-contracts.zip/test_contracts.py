"""Behavioral conformance checks against a fictional case; no external effects."""
from copy import deepcopy
import tempfile
import unittest
from validate_contracts import (HERE,ContractError,CommitHarness,validate_bundle,load_json,digest,check_case_transition,retry_disposition,record_ref)

BASE=load_json(HERE/'worked-case.json')
NOW='2026-09-03T10:00:00Z'
def rec(bundle,id,v=1):
    return next(r for r in bundle['records'] if r['record_id']==id and r['record_version']==v)
def update_binding(bundle,**changes):
    for r in bundle['records']:
        if r['record_type']=='action_intent' and r['record_id']=='action_offer':
            r['binding'].update(deepcopy(changes));r['binding_digest']=digest(r['binding'])
    value=rec(bundle,'action_offer')['binding_digest']
    rec(bundle,'approval_offer')['binding_digest']=value
    for r in bundle['records']:
        if r['record_type']=='execution_receipt':r['binding_digest']=value
    bundle['commands'][0]['binding_digest']=value
def update_terms(bundle,**changes):
    for r in bundle['records']:
        if r['record_type']=='agreement':
            r['terms'].update(deepcopy(changes));r['terms_digest']=digest(r['terms'])
            for acceptance in r['acceptances']:acceptance['terms_digest']=r['terms_digest']
    update_binding(bundle,terms_digest=rec(bundle,'agreement_demo')['terms_digest'])

class ContractTests(unittest.TestCase):
    def setUp(self):self.bundle=deepcopy(BASE)
    def rejects(self,code,fn):
        with self.assertRaises(ContractError) as raised:fn()
        self.assertEqual(code,raised.exception.code,raised.exception.detail)
    def validate(self):return validate_bundle(self.bundle)
    def commit(self,harness=None,command=None,now=NOW,actor='actor_operator',tenant='tenant_demo'):
        h=harness or CommitHarness(self.bundle)
        return h.commit(command or self.bundle['commands'][0],trusted_tenant=tenant,trusted_actor=actor,now=now)

    def test_valid_worked_case(self):
        index=self.validate();self.assertEqual(89,len(index.records))
        final=rec(self.bundle,'position_demo',2)
        self.assertEqual('7000000',final['reconciled_debtor_payments']['units'])
        self.assertEqual('800000',final['effective_releases']['units'])
        self.assertEqual('0',final['asserted_outstanding']['units'])

    def test_approval_only_schedules_work(self):
        result=self.commit()
        self.assertEqual('SCHEDULED',result['domain_status'])
        self.assertFalse(result['external_effect_committed'])

    def test_same_request_returns_existing_result(self):
        h=CommitHarness(self.bundle);first=self.commit(h)
        c=deepcopy(self.bundle['commands'][0]);c['command_id']='command_retry';c['requested_at']='2026-09-03T10:00:01Z'
        replay=self.commit(h,c)
        self.assertTrue(replay['replayed']);self.assertEqual(first['binding_digest'],replay['binding_digest'])
        self.assertEqual(10000,h.reserved_cost[('tenant_demo','grant_operator')])

    def test_same_request_key_different_target_is_conflict(self):
        h=CommitHarness(self.bundle);self.commit(h)
        c=deepcopy(self.bundle['commands'][0]);c['target_ref']['version']=2
        self.rejects('IDEMPOTENCY_CONFLICT',lambda:self.commit(h,c))

    def test_fresh_retry_key_cannot_repeat_action(self):
        h=CommitHarness(self.bundle);self.commit(h)
        c=deepcopy(self.bundle['commands'][0]);c['idempotency_key']='force_retry'
        self.rejects('ACTION_ALREADY_COMMITTED',lambda:self.commit(h,c))

    def test_caller_cannot_change_tenant(self):
        self.rejects('TENANT_MISMATCH',lambda:self.commit(tenant='tenant_other'))

    def test_caller_cannot_impersonate_executor(self):
        self.rejects('ACTOR_MISMATCH',lambda:self.commit(actor='actor_other'))

    def test_reference_cannot_cross_tenant(self):
        rec(self.bundle,'ev_contract')['tenant_id']='tenant_other'
        self.rejects('TENANT_MISMATCH',self.validate)

    def test_unresolved_reference_is_rejected(self):
        rec(self.bundle,'passport_demo')['evidence_refs'][0]['id']='ev_missing'
        self.rejects('MISSING_REFERENCE',self.validate)

    def test_unknown_command_fields_are_rejected(self):
        h=CommitHarness(self.bundle);c=deepcopy(self.bundle['commands'][0]);c['override_policy']=True
        self.rejects('SCHEMA_INVALID',lambda:self.commit(h,c))

    def test_money_never_uses_floating_point(self):
        rec(self.bundle,'position_demo')['asserted_outstanding']['units']=78000.0
        self.rejects('SCHEMA_INVALID',self.validate)

    def test_currency_mismatch_is_rejected(self):
        rec(self.bundle,'position_demo',2)['reconciled_debtor_payments']['currency']='INR'
        self.rejects('CURRENCY_MISMATCH',self.validate)

    def test_invalid_calendar_instant_is_rejected(self):
        rec(self.bundle,'ev_contract')['observed_at']='2026-02-30T09:00:00Z'
        self.rejects('SCHEMA_INVALID',self.validate)

    def test_impossible_stage_and_substate_pair_is_rejected(self):
        rec(self.bundle,'case_demo')['state']['stage_state']='ENFORCEMENT_ACTIVE'
        self.rejects('SCHEMA_INVALID',self.validate)

    def test_material_state_change_blocks_old_commit(self):
        # New evidence arrives before commit; the case/passport material version has changed.
        later=deepcopy(rec(self.bundle,'passport_demo',2));later['record_version']=3;later['recorded_at']='2026-09-03T09:30:00Z';later['known_gaps']=['New contradictory evidence.']
        # Replace only the existing future v3 snapshot for this branch and remove its dependent closeout references.
        h=CommitHarness(self.bundle)
        h.index.records[('claim_passport','passport_demo',3)]=later
        h.index.histories[('claim_passport','passport_demo')]=[rec(self.bundle,'passport_demo'),rec(self.bundle,'passport_demo',2),later]
        self.rejects('STALE_REFERENCE',lambda:self.commit(h))

    def test_revoked_authority_blocks_commit(self):
        h=CommitHarness(self.bundle)
        rec(self.bundle,'grant_operator')['status']='REVOKED';rec(self.bundle,'grant_operator')['revoked_at']='2026-09-03T09:30:00Z'
        self.rejects('AUTHORITY_REVOKED_OR_INACTIVE',lambda:self.commit(h))

    def test_expired_authority_blocks_commit(self):
        # The operator's mandate is not an acceptance mandate in this fixture, so history stays valid.
        h=CommitHarness(self.bundle)
        rec(self.bundle,'grant_operator')['valid_until']='2026-09-03T09:30:00Z'
        self.rejects('AUTHORITY_EXPIRED',lambda:self.commit(h))

    def test_expired_approval_blocks_commit(self):
        rec(self.bundle,'approval_offer')['expires_at']='2026-09-03T09:30:00Z'
        self.rejects('APPROVAL_EXPIRED',self.commit)

    def test_stale_approval_digest_is_rejected(self):
        rec(self.bundle,'approval_offer')['binding_digest']='sha256:'+'0'*64
        self.rejects('APPROVAL_BINDING_MISMATCH',self.commit)

    def test_action_binding_cannot_be_edited_in_place(self):
        rec(self.bundle,'action_offer')['binding']['channel']='VOICE'
        self.rejects('ACTION_BINDING_MUTATED',self.validate)

    def test_terms_changed_without_rebinding_are_rejected(self):
        for r in self.bundle['records']:
            if r['record_type']=='agreement':
                r['terms']['confidentiality']='ALTERED';r['terms_digest']=digest(r['terms'])
                for a in r['acceptances']:a['terms_digest']=r['terms_digest']
        self.rejects('TERMS_BINDING_MISMATCH',self.commit)

    def test_below_floor_offer_is_rejected_even_with_matching_approval(self):
        update_terms(self.bundle,amount={'currency':'USD','exponent':2,'units':'6900000'})
        self.rejects('SETTLEMENT_OUTSIDE_AUTHORITY',self.commit)

    def test_unsupported_nonfinancial_terms_require_another_profile(self):
        update_terms(self.bundle,admissions=['Novel admission requested.'])
        self.rejects('UNSUPPORTED_NONFINANCIAL_TERMS',self.commit)

    def test_budget_cap_cannot_be_exceeded(self):
        update_binding(self.bundle,proposed_cost={'currency':'USD','exponent':2,'units':'200001'})
        self.rejects('BUDGET_EXCEEDED',self.commit)

    def test_private_evidence_cannot_be_disclosed(self):
        update_binding(self.bundle,content_refs=[{'type':'evidence_item','id':'ev_private_strategy','version':1}])
        self.rejects('DISCLOSURE_DENIED',self.commit)

    def test_suspended_capability_blocks_commit(self):
        rec(self.bundle,'capability_offer')['status']='SUSPENDED'
        self.rejects('CAPABILITY_UNAVAILABLE',self.commit)

    def test_denied_policy_blocks_commit(self):
        rec(self.bundle,'policy_offer')['decision']='DENY'
        self.rejects('POLICY_NOT_ALLOWED',self.commit)

    def test_precautionary_hold_blocks_affected_action(self):
        rec(self.bundle,'case_demo',2)['state']['holds']=[{'hold_id':'hold_demo','code':'COMPLIANCE_HOLD','blocked_actions':['settlement.offer'],'party_refs':[],'route_codes':[],'set_at':'2026-09-02T09:00:00Z','review_at':'2026-09-04T09:00:00Z','setter_id':'actor_reviewer','release_authority_id':'actor_reviewer','basis_refs':[{'type':'evidence_item','id':'ev_rules','version':1}],'status':'ACTIVE'}]
        self.rejects('ACTIVE_HOLD',self.commit)

    def test_reported_payment_cannot_reduce_reconciled_balance(self):
        rec(self.bundle,'allocation_demo')['payment_ref']['version']=1
        self.rejects('UNRECONCILED_PAYMENT',self.validate)

    def test_other_proceeds_are_not_debtor_recovery(self):
        for r in self.bundle['records']:
            if r['record_type']=='payment':r['source_kind']='INSURANCE_PROCEEDS'
        self.rejects('NON_DEBTOR_PROCEEDS_AS_RECOVERY',self.validate)

    def test_duplicate_payment_transaction_is_rejected(self):
        payment=deepcopy(rec(self.bundle,'payment_demo',2));payment['record_id']='payment_duplicate';payment['record_version']=1
        self.bundle['records'].append(payment)
        self.rejects('DUPLICATE_PAYMENT_IDENTITY',self.validate)

    def test_payment_cannot_be_allocated_twice_across_cases(self):
        allocation=deepcopy(rec(self.bundle,'allocation_demo'));allocation['record_id']='allocation_duplicate';allocation['case_id']='case_linked'
        self.bundle['records'].append(allocation)
        self.rejects('PAYMENT_OVERALLOCATED',self.validate)

    def test_release_cannot_precede_required_payment(self):
        rec(self.bundle,'agreement_demo',4)['status']='ACCEPTED';rec(self.bundle,'agreement_demo',4)['release_effective_at']=None
        self.rejects('RELEASE_BEFORE_FULFILLMENT',self.validate)

    def test_unknown_recovery_is_not_zero(self):
        rec(self.bundle,'outcome_assessment')['debtor_recovery']['value']={'currency':'USD','exponent':2,'units':'0'}
        self.rejects('SCHEMA_INVALID',self.validate)

    def test_assessment_delivery_is_not_observed_recovery(self):
        value=rec(self.bundle,'outcome_assessment')['debtor_recovery'];value.update(status='OBSERVED',value={'currency':'USD','exponent':2,'units':'0'},basis_refs=[{'type':'evidence_item','id':'ev_assessment','version':1}])
        self.rejects('ASSESSMENT_AS_RECOVERY',self.validate)

    def test_case_cannot_close_with_active_service(self):
        rec(self.bundle,'service_operate',2)['status']='ACTIVE'
        self.rejects('ACTIVE_SERVICE_AT_CLOSURE',self.validate)

    def test_completed_case_retains_owned_administrative_duties(self):
        self.validate();case=rec(self.bundle,'case_demo',6)
        self.assertEqual('PENDING',case['state']['completion']['export_administrative']['status'])
        self.assertEqual('actor_creditor',case['state']['completion']['export_administrative']['owner_id'])

    def test_provider_acceptance_conditions_must_be_resolved(self):
        rec(self.bundle,'work_demo',2)['conditions_resolved']=False
        self.rejects('PROVIDER_NOT_ACCEPTED',self.validate)

    def test_exact_acceptance_cannot_target_different_terms(self):
        rec(self.bundle,'agreement_demo',3)['acceptances'][1]['terms_digest']='sha256:'+'0'*64
        self.rejects('ACCEPTANCE_TERMS_MISMATCH',self.validate)

    def test_later_information_cannot_enter_earlier_decision(self):
        rec(self.bundle,'decision_demo')['available_fact_refs'].append({'type':'evidence_item','id':'ev_bank','version':1})
        self.rejects('FUTURE_REFERENCE',self.validate)

    def test_deterministic_selection_has_no_invented_probability(self):
        rec(self.bundle,'decision_demo')['selection_probability']=0.5
        self.rejects('INVENTED_PROPENSITY',self.validate)

    def test_timeout_is_not_permission_to_send_again(self):
        self.assertEqual('RECONCILE_EXISTING_OPERATION',retry_disposition(rec(self.bundle,'receipt_offer')))
        self.assertEqual('DO_NOT_REDISPATCH',retry_disposition(rec(self.bundle,'receipt_offer',2)))

    def test_two_competing_intents_cannot_reserve_one_obligation(self):
        other=deepcopy(rec(self.bundle,'action_offer'));other['record_id']='action_other';other['approval_refs']=[{'type':'approval','id':'approval_other','version':1}];other['idempotency_key']='other_offer'
        approval=deepcopy(rec(self.bundle,'approval_offer'));approval['record_id']='approval_other';approval['action_ref']['id']='action_other'
        self.bundle['records'] += [other,approval]
        h=CommitHarness(self.bundle);self.commit(h)
        cmd=deepcopy(self.bundle['commands'][0]);cmd['command_id']='command_other';cmd['target_ref']['id']='action_other';cmd['idempotency_key']='other_offer'
        self.rejects('COMPETING_COMMITMENT',lambda:self.commit(h,cmd))

    def test_reopen_requires_authority(self):
        before=rec(self.bundle,'case_demo',6);after=deepcopy(before);after['record_version']=7;after['state']['lifecycle_stage']='ASSESSMENT';after['state']['stage_state']='IN_REVIEW'
        self.rejects('TRANSITION_AUTHORITY_REQUIRED',lambda:check_case_transition(before,after,reason='PAYMENT_REVERSAL',authority_verified=False))

    def test_normal_transition_preserves_identity_and_version(self):
        self.assertTrue(check_case_transition(rec(self.bundle,'case_demo',2),rec(self.bundle,'case_demo',3),reason='AUTHORIZED_EXECUTION_STARTED',authority_verified=True))

    def test_duplicate_json_keys_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            from pathlib import Path
            p=Path(d)/'duplicate.json';p.write_text('{"tenant_id":"tenant_demo","tenant_id":"tenant_other"}')
            self.rejects('DUPLICATE_JSON_KEY',lambda:load_json(p))

    def test_service_request_has_a_typed_admission_contract(self):
        command={'schema_version':'0.1.0','command_id':'command_service_request','tenant_id':'tenant_demo','actor_id':'actor_operator','principal_ref':{'type':'party','id':'party_creditor','version':1},'idempotency_key':'service_request_demo','requested_at':NOW,'expected_refs':[{'type':'case','id':'case_demo','version':2}],'operation':'service.request','payload':{'case_ref':{'type':'case','id':'case_demo','version':2},'kind':'MONITOR','scope_description':'A requested monitoring service, not automatically active.','window':deepcopy(rec(self.bundle,'service_operate')['window']),'cost_cap':{'currency':'USD','exponent':2,'units':'10000'},'authority_ref':{'type':'authority_grant','id':'grant_operator','version':1}}}
        self.bundle['commands'].append(command)
        self.validate()

    def test_request_cannot_inject_server_owned_completion_state(self):
        self.test_service_request_has_a_typed_admission_contract()
        self.bundle['commands'][-1]['payload']['status']='FULFILLED'
        self.rejects('SCHEMA_INVALID',self.validate)

    def test_assessment_only_can_close_operations_with_unpaid_claim(self):
        cutoff='2026-09-02T09:00:00Z'
        self.bundle['records']=[r for r in self.bundle['records'] if r['recorded_at']<=cutoff and r['record_type'] not in {'work_order','strategy_plan','event'} and r['record_id']!='service_operate']
        self.bundle['commands']=[];self.bundle['checkpoints']=self.bundle['checkpoints'][:2]
        case=rec(self.bundle,'case_demo',2)
        case['service_request_refs']=[{'type':'service_request','id':'service_assess','version':2}]
        pending=deepcopy(case);pending['record_version']=3;pending['recorded_at']='2026-09-02T09:01:00Z';pending['state'].update(lifecycle_stage='CLOSURE',stage_state='CLOSURE_REVIEW')
        self.bundle['records'].append(pending)
        closed=deepcopy(pending);closed['record_version']=4;closed['recorded_at']='2026-09-02T09:02:00Z';closed['next_review_at']=None
        closed['state'].update(lifecycle_stage='CLOSED',stage_state='FINAL',closure_state='SERVICE_SCOPE_COMPLETE',payment_state='NONE')
        closed['state']['completion']['operational']={'status':'SATISFIED','basis_refs':[{'type':'evidence_item','id':'ev_assessment','version':1}],'owner_id':None,'reason':'Contracted assessment delivered.'}
        closed['closure_basis_refs']=[{'type':'evidence_item','id':'ev_assessment','version':1}]
        self.bundle['records'].append(closed)
        self.assertTrue(check_case_transition(case,pending,reason='SERVICE_DELIVERED',authority_verified=True))
        self.assertTrue(check_case_transition(pending,closed,reason='SCOPE_COMPLETE',authority_verified=True))
        self.validate()
        self.assertEqual('7800000',rec(self.bundle,'position_demo')['asserted_outstanding']['units'])
        self.assertEqual('UNKNOWN',rec(self.bundle,'outcome_assessment')['debtor_recovery']['status'])

    def test_reversal_restores_cash_balance_without_automatic_release_revival(self):
        at='2026-09-10T09:00:00Z'
        payment=deepcopy(rec(self.bundle,'payment_demo',2));payment.update(record_version=3,recorded_at=at,status='REVERSED');self.bundle['records'].append(payment)
        allocation=deepcopy(rec(self.bundle,'allocation_demo'));allocation.update(record_id='allocation_reverse',recorded_at=at,effective_at=at,kind='REVERSE',payment_ref={'type':'payment','id':'payment_demo','version':3},reverses_ref={'type':'allocation','id':'allocation_demo','version':1});self.bundle['records'].append(allocation)
        position=deepcopy(rec(self.bundle,'position_demo',2));position.update(record_version=3,recorded_at=at,as_of=at,reconciled_debtor_payments={'currency':'USD','exponent':2,'units':'0'},asserted_outstanding={'currency':'USD','exponent':2,'units':'7000000'});position['allocation_refs'].append({'type':'allocation','id':'allocation_reverse','version':1});self.bundle['records'].append(position)
        self.validate()
        self.assertEqual('800000',position['effective_releases']['units'])

    def test_reversal_needs_an_original_allocation(self):
        rec(self.bundle,'allocation_demo')['kind']='REVERSE'
        self.rejects('MISSING_REVERSAL_BASIS',self.validate)

if __name__=='__main__':unittest.main(verbosity=2)
